package com.securityresponse

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices

data class Crime(
    val id: Int,
    var type: String,
    var description: String,
    var lat: Double,
    var lon: Double,
    var status: String = "UNVERIFIED"
)

class MainActivity : ComponentActivity() {
    private val locationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SecurityResponseApp() }
        requestLocation()
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityResponseApp() {
    var role by remember { mutableStateOf("PUBLIC") }
    var showReport by remember { mutableStateOf(false) }
    var nextId by remember { mutableStateOf(1) }
    val crimes = remember { mutableStateListOf<Crime>() }

    Scaffold(topBar = { TopAppBar(title = { Text("Security Response Map") }) }) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Mode", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick={role="PUBLIC"}) { Text("Public") }
                    Button(onClick={role="OFFICER"}) { Text("Officer") }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().height(300.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("LIVE MAP", style = MaterialTheme.typography.headlineMedium)
                        Text("GPS location and incident markers will appear here.")
                        Text("Crime pins: ${crimes.size}")
                        Text("Location sharing: ${if (role=="OFFICER") "available" else "off"}")
                    }
                }
            }
            if (role=="PUBLIC") {
                item {
                    Button(onClick={showReport=true}, Modifier.fillMaxWidth()) {
                        Text("🚨 Report a Crime")
                    }
                }
            } else {
                item {
                    Button(onClick={}, Modifier.fillMaxWidth()) { Text("📍 Share Live Location") }
                    Button(onClick={}, Modifier.fillMaxWidth()) { Text("🧭 Navigate to Incident") }
                }
            }
            item { Text("Incidents", style = MaterialTheme.typography.titleLarge) }
            items(crimes, key={it.id}) { crime ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(crime.type, style = MaterialTheme.typography.titleMedium)
                        Text(crime.description)
                        Text("Status: ${crime.status}")
                        Text("Location: %.5f, %.5f".format(crime.lat, crime.lon))
                        if (role=="OFFICER") {
                            Button(onClick={crime.status="RESPONDING"}) { Text("Respond") }
                        }
                    }
                }
            }
        }
    }

    if (showReport) {
        ReportDialog(
            onCancel={showReport=false},
            onSubmit={ type, desc, lat, lon ->
                crimes.add(Crime(nextId++, type, desc, lat, lon))
                showReport=false
            }
        )
    }
}

@Composable
fun ReportDialog(
    onCancel: () -> Unit,
    onSubmit: (String,String,Double,Double) -> Unit
) {
    var type by remember { mutableStateOf("THEFT") }
    var desc by remember { mutableStateOf("") }
    var lat by remember { mutableStateOf("-25.7479") }
    var lon by remember { mutableStateOf("28.2293") }

    AlertDialog(
        onDismissRequest=onCancel,
        title={Text("Report a Crime")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(type,{type=it},label={Text("Crime type")})
                OutlinedTextField(desc,{desc=it},label={Text("Description")})
                OutlinedTextField(lat,{lat=it},label={Text("Latitude")})
                OutlinedTextField(lon,{lon=it},label={Text("Longitude")})
                Text("In production, GPS will fill these coordinates automatically.")
            }
        },
        confirmButton={
            Button(onClick={
                onSubmit(type,desc,lat.toDoubleOrNull() ?: -25.7479,lon.toDoubleOrNull() ?: 28.2293)
            }) { Text("Submit") }
        },
        dismissButton={TextButton(onClick=onCancel){Text("Cancel")}}
    )
}
