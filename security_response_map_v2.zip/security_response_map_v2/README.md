# Security Response Map v2
Android-first prototype for public crime reporting and authorized security response.

Included:
- Public/officer modes
- Crime report creation
- Editable latitude/longitude fields in prototype
- Incident list and status
- Location permissions
- Officer response action
- Project structure ready for real map/backend integration

Next production integrations:
1. Google Maps Compose
2. Fused GPS live tracking
3. Firebase Auth/Firestore
4. Real-time officer locations
5. Google Routes API
6. Push notifications
7. Admin web dashboard
8. Strong role-based security rules
